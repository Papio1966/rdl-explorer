import { expect, test } from "@playwright/test";

test("core Explorer navigation is available", async ({ page }) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Explore CFIHOS. Understand the data.", level: 1 }),
  ).toBeVisible();

  await page.getByRole("link", { name: "Document Types", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Document Types", level: 1 })).toBeVisible();

  await page.getByRole("link", { name: "About CFIHOS Explorer" }).click();
  await expect(page).toHaveURL(/\/about$/);

  await page.getByRole("link", { name: "User Guide" }).click();
  await expect(page).toHaveURL(/\/help$/);
});

test("document requirement traceability renders as a table", async ({ page }) => {
  await page.goto("/documents/CFIHOS-70000007");
  await expect(page.getByRole("heading", { name: "Required by Classes" })).toBeVisible();
  const table = page.locator(".document-class-requirement-table");
  await expect(table).toBeVisible();
  await expect(table.locator("tbody tr").first()).toBeVisible();
});

test("CIS Builder exposes the authoring workflow", async ({ page }) => {
  await page.goto("/cis");
  await expect(page.getByRole("heading", { name: "Contract Information Specification Builder" })).toBeVisible();
  await expect(page.getByLabel("Working CIS controls")).toBeVisible();
  await expect(page.getByRole("heading", { name: "Project & contract" })).toBeVisible();
  await expect(page.getByRole("button", { name: /2 Baseline review/i })).toBeVisible();
  await expect(page.getByRole("button", { name: /3 Overrides/i })).toBeVisible();
  await expect(page.getByRole("button", { name: /4 Export/i })).toBeVisible();
});

test("pilot status, provenance and feedback route are visible", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByText("Pilot", { exact: true })).toBeVisible();
  await expect(page.getByLabel("Current pilot data source: CFIHOS version 2.0")).toBeVisible();
  await expect(page.getByRole("link", { name: "Send pilot feedback" })).toHaveAttribute(
    "href",
    /mailto:alessandro@papioconsulting\.eu/,
  );
  await expect(page.getByLabel("Global CFIHOS search coming soon")).toBeDisabled();
});
