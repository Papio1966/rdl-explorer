import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

function read(path: string) {
  return readFileSync(new URL(`../${path}`, import.meta.url), "utf8");
}

const app = read("src/App.tsx");
const shell = read("src/components/AppShell.tsx");
const assistantApi = read("api/assistant.ts");
const cisBuilder = read("src/pages/CisBuilderPage.tsx");
const assistant = read("src/pages/AssistantPage.tsx");
const about = read("src/pages/AboutPage.tsx");
const help = read("src/pages/HelpPage.tsx");

const routes = [
  "/classes/tag",
  "/classes/equipment",
  "/documents",
  "/disciplines",
  "/lifecycle",
  "/dictionary",
  "/standards",
  "/units",
  "/model",
  "/validation",
  "/assistant",
  "/cis",
  "/about",
  "/help",
];

for (const route of routes) {
  assert.ok(app.includes(`path=\"${route}\"`) || app.includes(`to=\"${route}`), `Missing application route ${route}`);
}

for (const label of [
  "Tag Classes",
  "Equipment Classes",
  "Document Types",
  "Lifecycle Requirements",
  "AI Assistant",
  "CIS Builder",
  "Validation",
  "About CFIHOS Explorer",
  "User Guide",
]) {
  assert.ok(shell.includes(`label: \"${label}\"`), `Missing navigation item ${label}`);
}

assert.ok(app.includes("lazyNamed"), "Routes are no longer lazy loaded");
assert.ok(app.includes("<Suspense"), "Lazy routes must remain behind a Suspense boundary");
assert.ok(app.includes('role="status"'), "Route loading fallback must remain accessible");

assert.ok(cisBuilder.includes("localStorage"), "CIS Builder persistence contract is missing");
assert.ok(assistant.includes("ACTIVE CIS") || assistant.includes("Active CIS"), "Assistant active-CIS context indicator is missing");
assert.ok(assistant.includes("/api/assistant"), "Assistant no longer calls the server-side API endpoint");

assert.ok(assistantApi.includes("OPENAI_API_KEY"), "Assistant API key must remain server-side");
assert.ok(assistantApi.includes("OPENAI_MODEL"), "Assistant model configuration is missing");
assert.ok(assistantApi.includes("store: false"), "OpenAI request must continue to disable response storage");
assert.ok(assistantApi.includes("method") && assistantApi.includes("POST"), "Assistant endpoint must validate POST requests");

assert.ok(shell.includes("pilot-badge"), "Pilot status badge is missing from the application shell");
assert.ok(shell.includes("CFIHOS 2.0 reviewed snapshot"), "Pilot data-source provenance is missing from the shell");
assert.ok(shell.includes("Global search coming soon") && shell.includes("disabled"), "Unimplemented global search must remain visibly disabled during pilot");
assert.ok(shell.includes("alessandro@papioconsulting.eu"), "Pilot feedback route is missing from the application shell");
assert.ok(about.includes("controlled evaluation") && about.includes("pilot"), "About page must explain pilot status");
assert.ok(help.includes("not enabled in this pilot"), "User Guide must explain the global-search pilot limitation");
assert.ok(help.includes("Do not include confidential project information"), "Pilot feedback guidance must warn against confidential information");

console.log(`PASS routes: ${routes.length} critical application routes registered.`);
console.log("PASS navigation: critical Explorer capabilities remain discoverable.");
console.log("PASS performance contract: route-level lazy loading and accessible fallback are present.");
console.log("PASS CIS/Assistant contract: persistence, active CIS context and server-side AI boundary are present.");
console.log("PASS pilot readiness: status, provenance, honest search state and feedback route are present.");
console.log("\nApplication regression checks passed.");
